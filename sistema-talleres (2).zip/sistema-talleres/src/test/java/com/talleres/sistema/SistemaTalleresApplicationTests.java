package com.talleres.sistema;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SistemaTalleresApplicationTests {

	@Test
	void contextLoads() {
	}

}
