package com.talleres.sistema.dto;

import java.time.Instant;

import com.talleres.sistema.modelo.RolUsuario;

public class UsuarioDto {
    private String id;
    private String nombre;
    private String correo;
    private RolUsuario rol;
    private boolean activo;
    private Instant fechaUltimoLogin;

    public String getId() { return id; }
    public void setId(String id) { this.id = id; }

    public String getNombre() { return nombre; }
    public void setNombre(String nombre) { this.nombre = nombre; }

    public String getCorreo() { return correo; }
    public void setCorreo(String correo) { this.correo = correo; }

    public RolUsuario getRol() { return rol; }
    public void setRol(RolUsuario rol) { this.rol = rol; }

    public boolean isActivo() { return activo; }
    public void setActivo(boolean activo) { this.activo = activo; }

    public Instant getFechaUltimoLogin() { return fechaUltimoLogin; }
    public void setFechaUltimoLogin(Instant fechaUltimoLogin) { this.fechaUltimoLogin = fechaUltimoLogin; }
}