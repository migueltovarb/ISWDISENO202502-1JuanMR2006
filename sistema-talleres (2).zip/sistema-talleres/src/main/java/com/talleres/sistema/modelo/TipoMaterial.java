package com.talleres.sistema.modelo;

public enum TipoMaterial {
    PDF,
    VIDEO,
    LINK,
    OTRO
}