package com.talleres.sistema.modelo;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import java.time.Instant;

@Document(collection = "certificados")
public class Certificado {

    @Id
    private String id;

    private String usuarioId;
    private String tallerId;
    private String url; // ruta local del PDF (ej. certs/cert_... .pdf)
    private Instant fechaEmision;

    public Certificado() {}

    public Certificado(String usuarioId, String tallerId, String url, Instant fechaEmision) {
        this.usuarioId = usuarioId;
        this.tallerId = tallerId;
        this.url = url;
        this.fechaEmision = fechaEmision;
    }

    public String getId() { return id; }
    public void setId(String id) { this.id = id; }

    public String getUsuarioId() { return usuarioId; }
    public void setUsuarioId(String usuarioId) { this.usuarioId = usuarioId; }

    public String getTallerId() { return tallerId; }
    public void setTallerId(String tallerId) { this.tallerId = tallerId; }

    public String getUrl() { return url; }
    public void setUrl(String url) { this.url = url; }

    public Instant getFechaEmision() { return fechaEmision; }
    public void setFechaEmision(Instant fechaEmision) { this.fechaEmision = fechaEmision; }
}