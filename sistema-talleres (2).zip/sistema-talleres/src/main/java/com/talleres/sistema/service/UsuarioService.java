package com.talleres.sistema.service;

import com.talleres.sistema.modelo.Usuario;
import com.talleres.sistema.repository.UsuarioRepository;
import org.springframework.stereotype.Service;

import java.time.Instant;
import java.util.List;
import java.util.Optional;

@Service
public class UsuarioService {

    private final UsuarioRepository repo;

    public UsuarioService(UsuarioRepository repo) {
        this.repo = repo;
    }

    public Usuario crearUsuario(Usuario u) {
        // TODO: validar duplicados (correo) y en producción hashear password (BCrypt)
        // if(repo.findByCorreo(u.getCorreo()).isPresent()) throw new RuntimeException("Correo ya registrado");
        return repo.save(u);
    }

    public List<Usuario> listarUsuarios() {
        return repo.findAll();
    }

    public Optional<Usuario> buscarPorId(String id) {
        return repo.findById(id);
    }

    public Optional<Usuario> buscarPorCorreo(String correo) {
        return repo.findByCorreo(correo);
    }

    public Usuario registrarLogin(String id) {
        Usuario u = repo.findById(id).orElseThrow(() -> new RuntimeException("Usuario no encontrado"));
        u.setFechaUltimoLogin(Instant.now());
        return repo.save(u);
    }

    // Método simple de autenticación (compara password en claro; en producción usar hash)
    public Optional<Usuario> verificarCredenciales(String correo, String password) {
        return repo.findByCorreo(correo).filter(u -> u.getPassword() != null && u.getPassword().equals(password));
    }
}