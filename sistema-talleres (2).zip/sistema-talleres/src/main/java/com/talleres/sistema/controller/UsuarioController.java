package com.talleres.sistema.controller;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.talleres.sistema.dto.UsuarioDto;
import com.talleres.sistema.modelo.Usuario;
import com.talleres.sistema.service.UsuarioService;

@RestController
@RequestMapping("/api")
@CrossOrigin(origins = "*")
public class UsuarioController {

    private final UsuarioService service;

    public UsuarioController(UsuarioService service) {
        this.service = service;
    }

    @PostMapping("/usuarios")
    public ResponseEntity<UsuarioDto> crearUsuario(@RequestBody Usuario u) {
        Usuario saved = service.crearUsuario(u);
        return ResponseEntity.status(HttpStatus.CREATED).body(toDto(saved));
    }

    @GetMapping("/usuarios")
    public ResponseEntity<List<UsuarioDto>> listarUsuarios() {
        List<UsuarioDto> lista = service.listarUsuarios().stream().map(this::toDto).collect(Collectors.toList());
        return ResponseEntity.ok(lista);
    }

    @GetMapping("/usuarios/{id}")
    public ResponseEntity<UsuarioDto> getUsuario(@PathVariable String id) {
        return service.buscarPorId(id).map(u -> ResponseEntity.ok(toDto(u))).orElse(ResponseEntity.notFound().build());
    }

    @PostMapping("/auth/login")
    public ResponseEntity<UsuarioDto> login(@RequestBody LoginRequest req) {
        return service.verificarCredenciales(req.getCorreo(), req.getPassword())
                .map(u -> ResponseEntity.ok(toDto(u)))
                .orElse(ResponseEntity.status(HttpStatus.UNAUTHORIZED).build());
    }

    @PostMapping("/usuarios/{id}/login")
    public ResponseEntity<UsuarioDto> registrarLogin(@PathVariable String id) {
        Usuario updated = service.registrarLogin(id);
        return ResponseEntity.ok(toDto(updated));
    }

    private UsuarioDto toDto(Usuario u) {
        if (u == null) return null;
        UsuarioDto d = new UsuarioDto();
        d.setId(u.getId());
        d.setNombre(u.getNombre());
        d.setCorreo(u.getCorreo());
        d.setRol(u.getRol());
        d.setActivo(u.isActivo());
        d.setFechaUltimoLogin(u.getFechaUltimoLogin());
        return d;
    }

    public static class LoginRequest {
        private String correo;
        private String password;
        public String getCorreo() { return correo; }
        public void setCorreo(String correo) { this.correo = correo; }
        public String getPassword() { return password; }
        public void setPassword(String password) { this.password = password; }
    }
}