package com.talleres.sistema.modelo;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.index.Indexed;
import org.springframework.data.mongodb.core.mapping.Document;

import java.time.Instant;

@Document(collection = "usuarios")
public class Usuario {
    @Id
    private String id;
    private String nombre;
    @Indexed(unique = true)
    private String correo;
    private String password;
    private RolUsuario rol;
    private boolean activo = true;
    private Instant fechaUltimoLogin;

    public Usuario() {}

    public String getId() { return id; }
    public void setId(String id) { this.id = id; }

    public String getNombre() { return nombre; }
    public void setNombre(String nombre) { this.nombre = nombre; }

    public String getCorreo() { return correo; }
    public void setCorreo(String correo) { this.correo = correo; }

    public String getPassword() { return password; }
    public void setPassword(String password) { this.password = password; }

    public RolUsuario getRol() { return rol; }
    public void setRol(RolUsuario rol) { this.rol = rol; }

    public boolean isActivo() { return activo; }
    public void setActivo(boolean activo) { this.activo = activo; }

    public Instant getFechaUltimoLogin() { return fechaUltimoLogin; }
    public void setFechaUltimoLogin(Instant fechaUltimoLogin) { this.fechaUltimoLogin = fechaUltimoLogin; }
}