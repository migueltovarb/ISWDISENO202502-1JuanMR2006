package com.talleres.sistema.service;

import com.talleres.sistema.modelo.Taller;
import com.talleres.sistema.modelo.Material;
import com.talleres.sistema.repository.TallerRepository;
import org.springframework.stereotype.Service;

import java.util.Collections;
import java.util.List;
import java.util.Optional;

@Service
public class TallerService {

    private final TallerRepository repo;

    public TallerService(TallerRepository repo) {
        this.repo = repo;
    }

    public Taller crearTaller(Taller t) {
        if (t.getCuposDisponibles() == null && t.getCuposTotales() != null) {
            t.setCuposDisponibles(t.getCuposTotales());
        }
        return repo.save(t);
    }

    public List<Taller> listarTalleres() {
        return repo.findAll();
    }

    public Optional<Taller> buscarPorId(String id) {
        return repo.findById(id);
    }

    public List<Taller> listarPorInstructor(String instructorId) {
        return repo.findByInstructorId(instructorId);
    }

    public List<Material> listarMaterialesPorTaller(String tallerId) {
        Optional<Taller> opt = repo.findById(tallerId);
        if (opt.isPresent()) {
            List<Material> materiales = opt.get().getMateriales();
            return materiales != null ? materiales : Collections.<Material>emptyList();
        }
        return Collections.<Material>emptyList();
    }
}