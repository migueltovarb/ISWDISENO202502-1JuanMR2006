package com.talleres.sistema.controller;

import com.talleres.sistema.modelo.Certificado;
import com.talleres.sistema.service.certificadoService;
import org.springframework.core.io.FileSystemResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.io.File;
import java.io.IOException;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.Optional;

@RestController
@RequestMapping("/api")
public class CertificadoController {

    private final certificadoService certificadoService;

    public CertificadoController(certificadoService certificadoService) {
        this.certificadoService = certificadoService;
    }

    // DTO para recibir la petición de generación
    public static class GenerarCertificadoRequest {
        private String usuarioId;
        private String nombreUsuario;
        private String nombreTaller;

        public String getUsuarioId() { return usuarioId; }
        public void setUsuarioId(String usuarioId) { this.usuarioId = usuarioId; }

        public String getNombreUsuario() { return nombreUsuario; }
        public void setNombreUsuario(String nombreUsuario) { this.nombreUsuario = nombreUsuario; }

        public String getNombreTaller() { return nombreTaller; }
        public void setNombreTaller(String nombreTaller) { this.nombreTaller = nombreTaller; }
    }

    @PostMapping("/talleres/{tallerId}/certificados")
    public ResponseEntity<?> generarCertificado(@PathVariable String tallerId,
                                               @RequestBody GenerarCertificadoRequest req) {
        if (req == null || req.getUsuarioId() == null || req.getUsuarioId().isBlank()) {
            return ResponseEntity.badRequest().body(Map.of("error", "usuarioId es requerido"));
        }

        try {
            Certificado cert = certificadoService.generarCertificado(
                    req.getUsuarioId(),
                    tallerId,
                    req.getNombreUsuario(),
                    req.getNombreTaller()
            );
            return ResponseEntity.status(201).body(cert);
        } catch (Exception e) {
            // devuelve 500 con mensaje claro para depuración
            return ResponseEntity.status(500).body(Map.of("error", "Error al generar certificado", "detail", e.getMessage()));
        }
    }

    @GetMapping("/certificados/{id}")
    public ResponseEntity<?> obtenerMetadata(@PathVariable String id) {
        Optional<Certificado> maybe = certificadoService.findById(id);
        return maybe.<ResponseEntity<?>>map(ResponseEntity::ok)
                .orElseGet(() -> ResponseEntity.status(404).body(Map.of("error", "Certificado no encontrado")));
    }

    @GetMapping("/certificados/{id}/download")
    public ResponseEntity<?> downloadCertificado(@PathVariable String id) {
        Optional<FileSystemResource> resourceOpt = certificadoService.getFileResource(id);

        if (resourceOpt.isEmpty()) {
            // diferencia si falta metadata o falta el archivo físico
            Optional<Certificado> certMaybe = certificadoService.findById(id);
            if (certMaybe.isEmpty()) {
                return ResponseEntity.status(404).body(Map.of("error", "Certificado no encontrado"));
            } else {
                return ResponseEntity.status(404).body(Map.of(
                        "error", "Archivo del certificado no encontrado en servidor",
                        "expectedPath", certMaybe.get().getUrl()
                ));
            }
        }

        FileSystemResource file = resourceOpt.get();
        String filename = file.getFilename();
        long length;
        try {
            length = file.contentLength();
        } catch (IOException e) {
            return ResponseEntity.status(500).body(Map.of("error", "No se pudo leer el archivo del servidor", "detail", e.getMessage()));
        }

        return ResponseEntity.ok()
                .contentLength(length)
                .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\"" + filename + "\"")
                .contentType(MediaType.APPLICATION_PDF)
                .body(file);
    }

    // Endpoint temporal de depuración: muestra ruta absoluta y archivos dentro de 'certs'
    @GetMapping("/debug/certs")
    public ResponseEntity<?> listarArchivosCerts() {
        File dir = new File("certs"); // coincide con lo que genera el servicio por defecto
        if (!dir.exists() || !dir.isDirectory()) {
            return ResponseEntity.ok(Map.of(
                    "exists", false,
                    "expectedPath", dir.getAbsolutePath()
            ));
        }
        String[] names = dir.list();
        List<String> files = names == null ? List.of() : Arrays.asList(names);
        return ResponseEntity.ok(Map.of(
                "exists", true,
                "path", dir.getAbsolutePath(),
                "files", files
        ));
    }
}