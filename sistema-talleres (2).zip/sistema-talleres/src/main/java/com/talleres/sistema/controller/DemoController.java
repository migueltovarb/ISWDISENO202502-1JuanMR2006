package com.talleres.sistema.controller;

import java.time.Instant;
import java.util.ArrayList;
import java.util.List;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.talleres.sistema.modelo.RolUsuario;
import com.talleres.sistema.modelo.Taller;
import com.talleres.sistema.modelo.Usuario;
import com.talleres.sistema.repository.TallerRepository;
import com.talleres.sistema.repository.UsuarioRepository;

@RestController
@RequestMapping("/api/demo")
@CrossOrigin(origins = "*")
public class DemoController {

    private final UsuarioRepository usuarioRepo;
    private final TallerRepository tallerRepo;

    public DemoController(UsuarioRepository usuarioRepo, TallerRepository tallerRepo) {
        this.usuarioRepo = usuarioRepo;
        this.tallerRepo = tallerRepo;
    }

    @PostMapping("/populate")
    public ResponseEntity<List<String>> populateDemo() {
        List<String> ids = new ArrayList<>();

        Usuario instr = usuarioRepo.findByCorreo("instructor@demo.com").orElseGet(() -> {
            Usuario u = new Usuario();
            u.setNombre("Instructor Demo");
            u.setCorreo("instructor@demo.com");
            u.setPassword("pass123");
            u.setRol(RolUsuario.INSTRUCTOR);
            u.setActivo(true);
            return usuarioRepo.save(u);
        });

        Usuario est = usuarioRepo.findByCorreo("estudiante@demo.com").orElseGet(() -> {
            Usuario u = new Usuario();
            u.setNombre("Estudiante Demo");
            u.setCorreo("estudiante@demo.com");
            u.setPassword("pass123");
            u.setRol(RolUsuario.ESTUDIANTE);
            u.setActivo(true);
            return usuarioRepo.save(u);
        });

        // Usa instr y est asegurando que sus IDs no sean null
        String instructorId = instr.getId();
        if (instructorId == null) instructorId = usuarioRepo.findByCorreo("instructor@demo.com").map(Usuario::getId).orElse(null);

        Taller t1 = new Taller();
        t1.setTitulo("Introducción a Java");
        t1.setDescripcion("Fundamentos de Java y programación orientada a objetos");
        t1.setInstructorId(instructorId);
        t1.setFechaInicio(Instant.now());
        t1.setFechaFin(Instant.now().plusSeconds(60 * 60 * 24 * 7));
        t1.setCuposTotales(30);
        t1.setCuposDisponibles(30);
        t1.setModalidad(com.talleres.sistema.modelo.Modalidad.PRESENCIAL);
        t1.setPrecio(0.0);
        ids.add(tallerRepo.save(t1).getId());

        Taller t2 = new Taller();
        t2.setTitulo("Spring Boot - Básico");
        t2.setDescripcion("Construye APIs con Spring Boot y MongoDB");
        t2.setInstructorId(instructorId);
        t2.setFechaInicio(Instant.now().plusSeconds(60 * 60 * 24));
        t2.setFechaFin(Instant.now().plusSeconds(60 * 60 * 24 * 2));
        t2.setCuposTotales(20);
        t2.setCuposDisponibles(20);
        t2.setModalidad(com.talleres.sistema.modelo.Modalidad.VIRTUAL);
        t2.setPrecio(10.0);
        ids.add(tallerRepo.save(t2).getId());

        // Devuelve también los correos creados (útil para debug) - así usamos 'est' si lo quieres
        ids.add("instr:" + instr.getCorreo());
        ids.add("est:" + est.getCorreo());

        return ResponseEntity.ok(ids);
    }
}