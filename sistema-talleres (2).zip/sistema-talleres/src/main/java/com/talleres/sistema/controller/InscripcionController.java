package com.talleres.sistema.controller;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.talleres.sistema.dto.InscripcionDto;
import com.talleres.sistema.modelo.Inscripcion;
import com.talleres.sistema.service.InscripcionService;

@RestController
@RequestMapping("/api")
@CrossOrigin(origins = "*")
public class InscripcionController {

    private final InscripcionService service;

    public InscripcionController(InscripcionService service) {
        this.service = service;
    }

    @PostMapping("/talleres/{tallerId}/inscripciones")
    public ResponseEntity<InscripcionDto> inscribir(@PathVariable String tallerId, @RequestBody InscripcionRequest req) {
        Inscripcion ins = service.crearInscripcion(req.getUsuarioId(), tallerId, req.getMetodoPago());
        return ResponseEntity.status(HttpStatus.CREATED).body(toDto(ins));
    }

    @GetMapping("/usuarios/{usuarioId}/inscripciones")
    public ResponseEntity<List<InscripcionDto>> listarPorUsuario(@PathVariable String usuarioId) {
        List<InscripcionDto> lista = service.listarPorUsuario(usuarioId).stream().map(this::toDto).collect(Collectors.toList());
        return ResponseEntity.ok(lista);
    }

    @GetMapping("/inscripciones/{id}")
    public ResponseEntity<InscripcionDto> obtenerPorId(@PathVariable String id) {
        Optional<Inscripcion> opt = service.findById(id);
        return opt.map(ins -> ResponseEntity.ok(toDto(ins)))
                  .orElse(ResponseEntity.notFound().build());
    }

    @PostMapping("/inscripciones/{id}/pago")
    public ResponseEntity<InscripcionDto> pagar(@PathVariable String id) {
        Inscripcion updated = service.simularPago(id);
        return ResponseEntity.ok(toDto(updated));
    }

    private InscripcionDto toDto(Inscripcion i) {
        if (i == null) return null;
        InscripcionDto d = new InscripcionDto();
        d.setId(i.getId());
        d.setUsuarioId(i.getUsuarioId());
        d.setTallerId(i.getTallerId());
        d.setEstado(i.getEstado() != null ? i.getEstado().name() : null);
        d.setFechaRegistro(i.getFechaRegistro());
        d.setFechaPago(i.getFechaPago());
        d.setMetodoPago(i.getMetodoPago());
        return d;
    }

    public static class InscripcionRequest {
        private String usuarioId;
        private String metodoPago;
        public String getUsuarioId() { return usuarioId; }
        public void setUsuarioId(String usuarioId) { this.usuarioId = usuarioId; }
        public String getMetodoPago() { return metodoPago; }
        public void setMetodoPago(String metodoPago) { this.metodoPago = metodoPago; }
    }
}