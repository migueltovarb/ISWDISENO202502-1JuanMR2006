package com.talleres.sistema.service;

import com.talleres.sistema.modelo.Certificado;
import com.talleres.sistema.repository.CertificadoRepository;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.PDPage;
import org.apache.pdfbox.pdmodel.PDPageContentStream;
import org.apache.pdfbox.pdmodel.font.PDType1Font;
import org.springframework.core.io.FileSystemResource;
import org.springframework.stereotype.Service;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.time.Instant;
import java.util.Optional;
import java.util.UUID;

@Service
public class certificadoService {

    private final CertificadoRepository repo;

    public certificadoService(CertificadoRepository repo) {
        this.repo = repo;
    }

    public Certificado generarCertificado(String usuarioId, String tallerId,
                                         String nombreUsuario, String nombreTaller) {
        // evita duplicados
        Optional<Certificado> existente = repo.findByUsuarioIdAndTallerId(usuarioId, tallerId);
        if (existente.isPresent()) {
            return existente.get();
        }

        String certsDir = "certs";
        try {
            Files.createDirectories(new File(certsDir).toPath());
        } catch (IOException e) {
            throw new RuntimeException("No se pudo crear directorio de certificados", e);
        }

        String filename = "cert_" + UUID.randomUUID() + ".pdf";
        String fullPath = certsDir + File.separator + filename;

        // crear PDF sencillo
        try (PDDocument doc = new PDDocument()) {
            PDPage page = new PDPage();
            doc.addPage(page);

            try (PDPageContentStream cs = new PDPageContentStream(doc, page)) {
                cs.beginText();
                cs.setFont(PDType1Font.HELVETICA_BOLD, 18);
                cs.newLineAtOffset(50, 700);
                cs.showText("Certificado de Asistencia");
                cs.endText();

                cs.beginText();
                cs.setFont(PDType1Font.HELVETICA, 12);
                cs.newLineAtOffset(50, 660);
                cs.showText("Otorgado a: " + (nombreUsuario != null ? nombreUsuario : usuarioId));
                cs.endText();

                cs.beginText();
                cs.setFont(PDType1Font.HELVETICA, 12);
                cs.newLineAtOffset(50, 640);
                cs.showText("Por su participación en: " + (nombreTaller != null ? nombreTaller : tallerId));
                cs.endText();

                cs.beginText();
                cs.setFont(PDType1Font.HELVETICA_OBLIQUE, 10);
                cs.newLineAtOffset(50, 600);
                cs.showText("Emitido en: " + Instant.now().toString());
                cs.endText();
            }

            doc.save(fullPath);
        } catch (IOException e) {
            throw new RuntimeException("Error generando PDF del certificado", e);
        }

        Certificado cert = new Certificado(usuarioId, tallerId, fullPath, Instant.now());
        return repo.save(cert);
    }

    public Optional<Certificado> findById(String id) {
        return repo.findById(id);
    }

    public Optional<FileSystemResource> getFileResource(String id) {
        Optional<Certificado> maybe = repo.findById(id);
        if (maybe.isEmpty()) return Optional.empty();

        Certificado cert = maybe.get();
        File f = new File(cert.getUrl());
        if (!f.exists() || !f.isFile()) return Optional.empty();

        return Optional.of(new FileSystemResource(f));
    }
}