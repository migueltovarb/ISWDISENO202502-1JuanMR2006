package com.talleres.sistema.controller;

import com.talleres.sistema.dto.TallerDto;
import com.talleres.sistema.modelo.Taller;
import com.talleres.sistema.modelo.Material;
import com.talleres.sistema.service.TallerService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/api")
@CrossOrigin(origins = "*")
public class TallerController {

    private final TallerService service;

    public TallerController(TallerService service) {
        this.service = service;
    }

    @PostMapping("/talleres")
    public ResponseEntity<TallerDto> crearTaller(@RequestBody Taller t) {
        if (t == null) {
            return ResponseEntity.badRequest().build();
        }

        // inicializar campos que podrían ser null para evitar NPEs en la capa de servicio
        if (t.getCuposDisponibles() == null && t.getCuposTotales() != null) {
            t.setCuposDisponibles(t.getCuposTotales());
        } else if (t.getCuposDisponibles() == null) {
            t.setCuposDisponibles(0);
        }

        Taller saved = service.crearTaller(t);
        return ResponseEntity.status(HttpStatus.CREATED).body(toDto(saved));
    }

    @GetMapping("/talleres")
    public ResponseEntity<List<TallerDto>> listarTalleres() {
        List<Taller> talleres = service.listarTalleres();
        List<TallerDto> lista = talleres.stream().map(this::toDto).collect(Collectors.toList());
        return ResponseEntity.ok(lista);
    }

    @GetMapping("/talleres/{id}")
    public ResponseEntity<TallerDto> getTaller(@PathVariable String id) {
        Optional<Taller> opt = service.buscarPorId(id);
        if (opt.isEmpty()) {
            return ResponseEntity.notFound().build();
        }
        return ResponseEntity.ok(toDto(opt.get()));
    }

    // devolver materiales del taller (verifica que el taller exista primero)
    @GetMapping("/talleres/{id}/materiales")
    public ResponseEntity<List<Material>> materiales(@PathVariable String id) {
        Optional<Taller> opt = service.buscarPorId(id);
        if (opt.isEmpty()) {
            return ResponseEntity.notFound().build();
        }
        List<Material> lista = service.listarMaterialesPorTaller(id);
        // si no hay materiales, devolvemos 200 con lista vacía
        return ResponseEntity.ok(lista != null ? lista : List.of());
    }

    // Mapeo seguro a DTO
    private TallerDto toDto(Taller t) {
        if (t == null) return null;
        TallerDto d = new TallerDto();
        d.setId(t.getId());
        d.setTitulo(t.getTitulo());
        d.setDescripcion(t.getDescripcion());
        d.setInstructorId(t.getInstructorId());
        d.setFechaInicio(t.getFechaInicio());
        d.setFechaFin(t.getFechaFin());
        d.setCuposTotales(t.getCuposTotales());
        d.setCuposDisponibles(t.getCuposDisponibles());
        d.setModalidad(t.getModalidad());
        d.setPrecio(t.getPrecio());
        d.setMateriales(t.getMateriales() != null ? t.getMateriales() : List.of());
        return d;
    }
}