package com.talleres.sistema.modelo;

public enum EstadoInscripcion {
    PENDIENTE,
    PAGADO,
    CANCELADO,
    ASISTIDO
}