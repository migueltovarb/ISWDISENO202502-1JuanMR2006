package com.talleres.sistema.modelo;

public enum Modalidad {
    PRESENCIAL,
    VIRTUAL,
    HIBRIDO
}