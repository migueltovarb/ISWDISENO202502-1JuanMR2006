package com.talleres.sistema.modelo;

import java.time.Instant;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection = "materiales")
public class Material {

    @Id
    private String id;

    private String tallerId;
    private String nombre;
    private String descripcion;
    private String url;         // link al recurso o ruta
    private String tipo;        // "VIDEO", "PDF", "ENLACE", etc.
    private Instant fechaRegistro;
    private boolean disponible = true;

    public Material() {}

    // getters y setters
    public String getId() { return id; }
    public void setId(String id) { this.id = id; }

    public String getTallerId() { return tallerId; }
    public void setTallerId(String tallerId) { this.tallerId = tallerId; }

    public String getNombre() { return nombre; }
    public void setNombre(String nombre) { this.nombre = nombre; }

    public String getDescripcion() { return descripcion; }
    public void setDescripcion(String descripcion) { this.descripcion = descripcion; }

    public String getUrl() { return url; }
    public void setUrl(String url) { this.url = url; }

    public String getTipo() { return tipo; }
    public void setTipo(String tipo) { this.tipo = tipo; }

    public Instant getFechaRegistro() { return fechaRegistro; }
    public void setFechaRegistro(Instant fechaRegistro) { this.fechaRegistro = fechaRegistro; }

    public boolean isDisponible() { return disponible; }
    public void setDisponible(boolean disponible) { this.disponible = disponible; }
}