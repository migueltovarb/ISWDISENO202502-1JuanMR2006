package com.talleres.sistema;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SistemaTalleresApplication {

    public static void main(String[] args) {
        SpringApplication.run(SistemaTalleresApplication.class, args);
    }
}