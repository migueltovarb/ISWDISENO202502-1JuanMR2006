package com.talleres.sistema.repository;

import com.talleres.sistema.modelo.Certificado;
import org.springframework.data.mongodb.repository.MongoRepository;

import java.util.Optional;

public interface CertificadoRepository extends MongoRepository<Certificado, String> {
    Optional<Certificado> findByUsuarioIdAndTallerId(String usuarioId, String tallerId);
}