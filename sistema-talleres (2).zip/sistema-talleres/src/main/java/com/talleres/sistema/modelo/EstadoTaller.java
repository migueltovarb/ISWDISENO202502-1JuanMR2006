package com.talleres.sistema.modelo;

public enum EstadoTaller {
    ABIERTO,
    CERRADO,
    CANCELADO
}