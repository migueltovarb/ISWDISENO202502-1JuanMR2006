package com.talleres.sistema.modelo;

public enum RolUsuario {
    ADMIN,
    INSTRUCTOR,
    ESTUDIANTE
}