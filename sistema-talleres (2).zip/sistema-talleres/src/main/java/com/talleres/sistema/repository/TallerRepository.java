package com.talleres.sistema.repository;

import com.talleres.sistema.modelo.Taller;
import org.springframework.data.mongodb.repository.MongoRepository;

import java.util.List;

public interface TallerRepository extends MongoRepository<Taller, String> {
    List<Taller> findByInstructorId(String instructorId);
}