package com.talleres.sistema.repository;

import java.util.List;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import com.talleres.sistema.modelo.Inscripcion;

@Repository
public interface InscripcionRepository extends MongoRepository<Inscripcion, String> {
    List<Inscripcion> findByUsuarioId(String usuarioId);
    List<Inscripcion> findByTallerId(String tallerId);
}