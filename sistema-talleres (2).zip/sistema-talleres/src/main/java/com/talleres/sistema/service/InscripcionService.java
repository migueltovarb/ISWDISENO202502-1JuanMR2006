package com.talleres.sistema.service;

import java.time.Instant;
import java.util.List;
import java.util.Optional;

import org.bson.types.ObjectId;
import org.springframework.data.mongodb.core.FindAndModifyOptions;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;
import org.springframework.stereotype.Service;

import com.talleres.sistema.modelo.EstadoInscripcion;
import com.talleres.sistema.modelo.Inscripcion;
import com.talleres.sistema.modelo.Taller;
import com.talleres.sistema.repository.InscripcionRepository;

@Service
public class InscripcionService {

    private final InscripcionRepository insRepo;
    private final MongoTemplate mongoTemplate;

    public InscripcionService(InscripcionRepository insRepo, MongoTemplate mongoTemplate) {
        this.insRepo = insRepo;
        this.mongoTemplate = mongoTemplate;
    }

    public Inscripcion crearInscripcion(String usuarioId, String tallerId, String metodoPago) {
        // Manejar _id tanto String como ObjectId para Taller
        Query q;
        if (ObjectId.isValid(tallerId)) {
            q = new Query(Criteria.where("_id").is(new ObjectId(tallerId)).and("cuposDisponibles").gt(0));
        } else {
            q = new Query(Criteria.where("_id").is(tallerId).and("cuposDisponibles").gt(0));
        }
        Update u = new Update().inc("cuposDisponibles", -1);
        FindAndModifyOptions opt = new FindAndModifyOptions().returnNew(true);
        Taller updated = mongoTemplate.findAndModify(q, u, opt, Taller.class);
        if (updated == null) {
            throw new RuntimeException("No hay cupos disponibles para el taller " + tallerId);
        }

        Inscripcion ins = new Inscripcion();
        ins.setUsuarioId(usuarioId);
        ins.setTallerId(tallerId);
        ins.setEstado(EstadoInscripcion.PENDIENTE);
        ins.setFechaRegistro(Instant.now());
        ins.setMetodoPago(metodoPago);
        return insRepo.save(ins);
    }

    public List<Inscripcion> listarPorUsuario(String usuarioId) {
        return insRepo.findByUsuarioId(usuarioId);
    }

    public List<Inscripcion> listarPorTaller(String tallerId) {
        return insRepo.findByTallerId(tallerId);
    }

    // findById robusto: intenta repo.findById(id), si vacío intenta buscar _id como ObjectId
    public Optional<Inscripcion> findById(String id) {
        try {
            Optional<Inscripcion> direct = insRepo.findById(id);
            if (direct != null && direct.isPresent()) return direct;
        } catch (Exception ignored) {}

        try {
            if (ObjectId.isValid(id)) {
                Query q = Query.query(Criteria.where("_id").is(new ObjectId(id)));
                Inscripcion found = mongoTemplate.findOne(q, Inscripcion.class);
                return Optional.ofNullable(found);
            }
        } catch (Exception ignored) {}

        return Optional.empty();
    }

    public Inscripcion simularPago(String inscripcionId) {
        Inscripcion ins = findById(inscripcionId)
                .orElseThrow(() -> new RuntimeException("Inscripcion no encontrada"));
        ins.setEstado(EstadoInscripcion.PAGADO);
        ins.setFechaPago(Instant.now());
        return insRepo.save(ins);
    }
}