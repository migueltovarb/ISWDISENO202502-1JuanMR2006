package com.example.vehicleapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class VehicleApiApplicationTests {

	@Test
	void contextLoads() {
	}

}